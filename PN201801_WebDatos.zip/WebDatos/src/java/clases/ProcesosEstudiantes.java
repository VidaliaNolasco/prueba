
package clases;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

/* @author Vidalia Nolasco*/
public class ProcesosEstudiantes {
    static String SQL;
    static Connection conn = null;
    static PreparedStatement ps = null;
    
    public static LinkedList<Estudiante> getEstudiante(String sqlCad){
        LinkedList<Estudiante> listaEstudiantes = new LinkedList<Estudiante>();
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Universidad","root","jorge_perez100");
            conn.setAutoCommit(false);
            ps = (PreparedStatement)conn.prepareStatement(sqlCad,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Estudiante estudiante = new Estudiante();
                estudiante.setCarnet(rs.getString("CarnetID"));
                estudiante.setNombre(rs.getString("Nombre"));
                estudiante.setApellidos(rs.getString("Apellidos"));
                estudiante.setFechaNac(rs.getDate("FechaNacimiento"));
                estudiante.setFechaIng(rs.getDate("FechaIngreso"));
                estudiante.setTelefono(rs.getString("Telefono"));
                estudiante.setDireccion(rs.getString("Direccion"));
                
                listaEstudiantes.add(estudiante);
            }
            ps.close();
            rs.close();
            conn.close();
        }catch(Exception e){
            
        }
        return listaEstudiantes;
    }
    public static String actualizar(String SQL)throws ClassNotFoundException, InstantiationException,
            SQLException, IllegalAccessException{
        String mensaje;
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Universidad","root","jorge_perez100");
            Statement st = (Statement)conn.createStatement();
            st.execute(SQL);
            mensaje = "¡Proceso Exitoso!";
        }catch(Exception e){
            mensaje = e.getMessage();
        }
        return mensaje;
    }
}
