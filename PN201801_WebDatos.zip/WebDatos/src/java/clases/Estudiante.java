
package clases;

import java.util.Date;

/*@author Vidalia Nolasco*/
public class Estudiante {
    private String carnet;
    private String nombre;
    private String apellidos;
    private String telefono;
    private String direccion;
    private Date fechaNac;
    private Date fechaIng;
    
    public String getCarnet(){return carnet;}
    public String getNombre(){return nombre;}
    public String getApellidos(){return apellidos;}
    public Date getFechaNac(){return fechaNac;}
    public Date getFechaIng(){return fechaIng;}
    public String getTelefono(){return telefono;}
    public String getDireccion(){return direccion;}
    
    public void setCarnet(String carnet){this.carnet = carnet;}
     public void setApellidos(String apellidos){this.apellidos = apellidos;}
    public void setNombre(String nombre){this.nombre = nombre;}
    public void setFechaNac(Date fechaNac){this.fechaNac = fechaNac;}
    public void setFechaIng(Date fechaIng){this.fechaIng = fechaIng;}
    public void setTelefono(String telefono){this.telefono = telefono;}
    public void setDireccion(String direccion){this.direccion = direccion;}
        
}
